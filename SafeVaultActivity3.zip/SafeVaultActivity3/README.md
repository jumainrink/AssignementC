# SafeVault Activity 3 - Debugging and Securing the Application

This project is the final SafeVault security activity.

It focuses on debugging and fixing common vulnerabilities such as:

- SQL injection
- Cross-site scripting, also known as XSS
- Weak input validation
- Unsafe output handling

## Project Structure

```text
SafeVaultActivity3/
│
├── Controllers/
│   └── SafeVaultController.cs
│
├── Data/
│   └── SecureUserRepository.cs
│
├── Services/
│   └── SecurityHelper.cs
│
├── Tests/
│   └── TestSecurityFixes.cs
│
├── database.sql
├── SafeVaultActivity3.csproj
└── README.md
```

## Vulnerabilities Identified

1. SQL injection risk caused by unsafe SQL query construction.
2. XSS risk caused by displaying user input without sanitization or encoding.
3. Weak validation for username and email fields.

## Fixes Applied

1. SQL queries were rewritten using parameterized statements.
2. User input is sanitized before being processed.
3. HTML content is encoded to reduce XSS risk.
4. Username and email validation were added.
5. NUnit tests were created to simulate SQL injection and XSS attacks.

## Testing

The tests verify that:

- SQL injection strings are rejected.
- Dangerous script tags are removed.
- HTML tags are not displayed as executable code.
- Valid usernames and emails are accepted.
- Invalid emails are rejected.

## How to Run Tests

Open the project folder in the terminal and run:

```bash
dotnet restore
dotnet test
```

## Copilot Assistance Summary

Microsoft Copilot was used to suggest secure coding patterns, identify risky query construction, recommend input sanitization techniques, and generate unit tests for SQL injection and XSS attack scenarios.
