using MySql.Data.MySqlClient;
using SafeVaultSecureApp.Services;

namespace SafeVaultSecureApp.Data;

public class SecureUserRepository
{
    private readonly string connectionString;

    public SecureUserRepository(string connectionString)
    {
        this.connectionString = connectionString;
    }

    public void AddUser(string username, string email)
    {
        if (!SecurityHelper.IsValidUsername(username))
            throw new ArgumentException("Invalid username.");

        if (!SecurityHelper.IsValidEmail(email))
            throw new ArgumentException("Invalid email.");

        string safeUsername = SecurityHelper.SanitizeInput(username);
        string safeEmail = SecurityHelper.SanitizeInput(email);

        using MySqlConnection connection = new MySqlConnection(connectionString);

        string query = "INSERT INTO Users (Username, Email) VALUES (@Username, @Email)";

        using MySqlCommand command = new MySqlCommand(query, connection);

        command.Parameters.AddWithValue("@Username", safeUsername);
        command.Parameters.AddWithValue("@Email", safeEmail);

        connection.Open();
        command.ExecuteNonQuery();
    }

    public bool UserExists(string username)
    {
        using MySqlConnection connection = new MySqlConnection(connectionString);

        string query = "SELECT COUNT(*) FROM Users WHERE Username = @Username";

        using MySqlCommand command = new MySqlCommand(query, connection);

        command.Parameters.AddWithValue("@Username", username);

        connection.Open();

        int count = Convert.ToInt32(command.ExecuteScalar());

        return count > 0;
    }
}
