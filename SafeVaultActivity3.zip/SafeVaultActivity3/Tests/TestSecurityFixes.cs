using NUnit.Framework;
using SafeVaultSecureApp.Services;

namespace SafeVaultSecureApp.Tests;

[TestFixture]
public class TestSecurityFixes
{
    [Test]
    public void TestSQLInjectionUsernameIsRejected()
    {
        string maliciousInput = "' OR '1'='1";

        bool result = SecurityHelper.IsValidUsername(maliciousInput);

        Assert.IsFalse(result);
    }

    [Test]
    public void TestDropTableInjectionIsRejected()
    {
        string maliciousInput = "admin; DROP TABLE Users;";

        bool result = SecurityHelper.IsValidUsername(maliciousInput);

        Assert.IsFalse(result);
    }

    [Test]
    public void TestXSSScriptIsRemoved()
    {
        string maliciousInput = "<script>alert('XSS')</script>";

        string sanitized = SecurityHelper.SanitizeInput(maliciousInput);

        Assert.IsFalse(sanitized.Contains("<script>"));
        Assert.IsFalse(sanitized.Contains("</script>"));
    }

    [Test]
    public void TestHtmlIsEncoded()
    {
        string maliciousInput = "<h1>Hello</h1>";

        string sanitized = SecurityHelper.SanitizeInput(maliciousInput);

        Assert.IsFalse(sanitized.Contains("<h1>"));
        Assert.IsFalse(sanitized.Contains("</h1>"));
    }

    [Test]
    public void TestValidUsernameIsAccepted()
    {
        string username = "Jean_Marie123";

        bool result = SecurityHelper.IsValidUsername(username);

        Assert.IsTrue(result);
    }

    [Test]
    public void TestValidEmailIsAccepted()
    {
        string email = "student@example.com";

        bool result = SecurityHelper.IsValidEmail(email);

        Assert.IsTrue(result);
    }

    [Test]
    public void TestInvalidEmailIsRejected()
    {
        string email = "student.example.com";

        bool result = SecurityHelper.IsValidEmail(email);

        Assert.IsFalse(result);
    }
}
