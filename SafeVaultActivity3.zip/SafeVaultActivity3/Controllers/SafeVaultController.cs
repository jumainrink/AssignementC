using Microsoft.AspNetCore.Mvc;
using SafeVaultSecureApp.Services;

namespace SafeVaultSecureApp.Controllers;

public class SafeVaultController : Controller
{
    [HttpPost]
    public IActionResult Submit(string username, string email)
    {
        if (!SecurityHelper.IsValidUsername(username))
        {
            return BadRequest("Invalid username.");
        }

        if (!SecurityHelper.IsValidEmail(email))
        {
            return BadRequest("Invalid email.");
        }

        string safeUsername = SecurityHelper.SanitizeInput(username);
        string safeEmail = SecurityHelper.SanitizeInput(email);

        return Ok($"User {safeUsername} with email {safeEmail} submitted securely.");
    }
}
