using System.Net;
using System.Text.RegularExpressions;

namespace SafeVaultSecureApp.Services;

public static class SecurityHelper
{
    public static string SanitizeInput(string input)
    {
        if (string.IsNullOrWhiteSpace(input))
            return string.Empty;

        input = input.Trim();

        input = Regex.Replace(
            input,
            "<.*?>",
            string.Empty,
            RegexOptions.IgnoreCase
        );

        return WebUtility.HtmlEncode(input);
    }

    public static bool IsValidUsername(string username)
    {
        if (string.IsNullOrWhiteSpace(username))
            return false;

        return Regex.IsMatch(username, @"^[a-zA-Z0-9_.-]{3,50}$");
    }

    public static bool IsValidEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
            return false;

        return Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
    }
}
