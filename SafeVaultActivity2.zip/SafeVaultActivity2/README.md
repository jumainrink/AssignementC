# SafeVault Activity 2 - Authentication and Authorization

This project implements Activity 2 for the SafeVault application.

It includes:

- User model
- Secure password hashing using BCrypt
- Login authentication
- Role-based authorization
- Admin dashboard access control
- NUnit tests for authentication and authorization

## Project Structure

```text
SafeVaultActivity2/
│
├── Models/
│   └── User.cs
│
├── Services/
│   ├── PasswordHasher.cs
│   ├── AuthService.cs
│   └── AuthorizationService.cs
│
├── Controllers/
│   └── AdminController.cs
│
├── Tests/
│   └── TestAuthenticationAuthorization.cs
│
├── SafeVaultActivity2.csproj
└── README.md
```

## Requirements

- .NET 8 SDK
- NuGet packages:
  - BCrypt.Net-Next
  - NUnit
  - NUnit3TestAdapter
  - Microsoft.NET.Test.Sdk

## How to Run Tests

Open the project folder in the terminal and run:

```bash
dotnet restore
dotnet test
```

## Activity Summary

This activity secures the SafeVault application by adding authentication and authorization.

Authentication verifies a user's username and password. Passwords are protected using BCrypt hashing instead of being stored as plain text.

Authorization uses roles such as `admin` and `user`. The Admin Dashboard is protected so that only users with the `admin` role can access it.

The tests verify:

- Valid login
- Invalid login
- Password hashing
- Admin access allowed
- Normal user access denied
