using NUnit.Framework;
using SafeVaultSecureApp.Controllers;
using SafeVaultSecureApp.Models;
using SafeVaultSecureApp.Services;

namespace SafeVaultSecureApp.Tests;

[TestFixture]
public class TestAuthenticationAuthorization
{
    [Test]
    public void TestValidLogin()
    {
        AuthService authService = new AuthService();

        authService.RegisterUser("admin", "SecurePass123", "admin");

        User? user = authService.Authenticate("admin", "SecurePass123");

        Assert.IsNotNull(user);
        Assert.AreEqual("admin", user!.Username);
    }

    [Test]
    public void TestInvalidLogin()
    {
        AuthService authService = new AuthService();

        authService.RegisterUser("admin", "SecurePass123", "admin");

        User? user = authService.Authenticate("admin", "WrongPassword");

        Assert.IsNull(user);
    }

    [Test]
    public void TestAdminAccessAllowed()
    {
        User adminUser = new User
        {
            Username = "admin",
            Role = "admin"
        };

        AdminController controller = new AdminController();

        string result = controller.AccessAdminDashboard(adminUser);

        Assert.AreEqual("Welcome to the Admin Dashboard.", result);
    }

    [Test]
    public void TestNormalUserAccessDenied()
    {
        User normalUser = new User
        {
            Username = "john",
            Role = "user"
        };

        AdminController controller = new AdminController();

        string result = controller.AccessAdminDashboard(normalUser);

        Assert.AreEqual("Access denied. Admin role required.", result);
    }

    [Test]
    public void TestPasswordIsHashed()
    {
        string password = "SecurePass123";

        string hash = PasswordHasher.HashPassword(password);

        Assert.AreNotEqual(password, hash);
        Assert.IsTrue(PasswordHasher.VerifyPassword(password, hash));
    }
}
