using SafeVaultSecureApp.Models;

namespace SafeVaultSecureApp.Services;

public static class AuthorizationService
{
    public static bool IsAdmin(User user)
    {
        return user.Role.ToLower() == "admin";
    }

    public static bool HasRole(User user, string requiredRole)
    {
        return user.Role.ToLower() == requiredRole.ToLower();
    }
}
