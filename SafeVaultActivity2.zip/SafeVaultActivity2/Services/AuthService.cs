using SafeVaultSecureApp.Models;

namespace SafeVaultSecureApp.Services;

public class AuthService
{
    private readonly List<User> users = new();

    public void RegisterUser(string username, string password, string role = "user")
    {
        string hashedPassword = PasswordHasher.HashPassword(password);

        users.Add(new User
        {
            UserID = users.Count + 1,
            Username = username,
            PasswordHash = hashedPassword,
            Role = role
        });
    }

    public User? Authenticate(string username, string password)
    {
        User? user = users.FirstOrDefault(u => u.Username == username);

        if (user == null)
            return null;

        bool isPasswordValid = PasswordHasher.VerifyPassword(password, user.PasswordHash);

        return isPasswordValid ? user : null;
    }
}
