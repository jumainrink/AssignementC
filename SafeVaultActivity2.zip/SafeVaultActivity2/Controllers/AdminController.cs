using SafeVaultSecureApp.Models;
using SafeVaultSecureApp.Services;

namespace SafeVaultSecureApp.Controllers;

public class AdminController
{
    public string AccessAdminDashboard(User user)
    {
        if (!AuthorizationService.IsAdmin(user))
        {
            return "Access denied. Admin role required.";
        }

        return "Welcome to the Admin Dashboard.";
    }
}
