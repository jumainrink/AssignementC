# SafeVault Secure Coding Activity

This project demonstrates secure coding practices for the SafeVault web application.

## Included Features

- Input validation
- Input sanitization
- SQL injection prevention using parameterized queries
- XSS protection
- NUnit security tests

## Files

- `webform.html`: Secure web form
- `database.sql`: Users table
- `Services/InputValidator.cs`: Input validation and sanitization logic
- `Data/UserRepository.cs`: Secure database access using parameterized queries
- `Controllers/UserController.cs`: Controller for form submission
- `Tests/TestInputValidation.cs`: NUnit tests for SQL injection and XSS

## Notes

Before running the project, update the database connection string inside:

`Controllers/UserController.cs`

You also need the following packages in your C# project:

- `MySql.Data`
- `NUnit`
- `NUnit3TestAdapter`
- `Microsoft.NET.Test.Sdk`
