using NUnit.Framework;
using SafeVault.Services;

namespace SafeVault.Tests
{
    [TestFixture]
    public class TestInputValidation
    {
        [Test]
        public void TestForSQLInjection()
        {
            string maliciousInput = "' OR '1'='1";

            bool result = InputValidator.IsValidUsername(maliciousInput);

            Assert.IsFalse(result);
        }

        [Test]
        public void TestForXSS()
        {
            string maliciousInput = "<script>alert('XSS')</script>";

            string sanitized = InputValidator.SanitizeInput(maliciousInput);

            Assert.IsFalse(sanitized.Contains("<script>"));
            Assert.IsFalse(sanitized.Contains("</script>"));
        }

        [Test]
        public void TestValidUsername()
        {
            string username = "Jean_Marie123";

            bool result = InputValidator.IsValidUsername(username);

            Assert.IsTrue(result);
        }

        [Test]
        public void TestInvalidUsernameWithSpecialCharacters()
        {
            string username = "admin; DROP TABLE Users;";

            bool result = InputValidator.IsValidUsername(username);

            Assert.IsFalse(result);
        }

        [Test]
        public void TestValidEmail()
        {
            string email = "student@example.com";

            bool result = InputValidator.IsValidEmail(email);

            Assert.IsTrue(result);
        }

        [Test]
        public void TestInvalidEmail()
        {
            string email = "student.example.com";

            bool result = InputValidator.IsValidEmail(email);

            Assert.IsFalse(result);
        }
    }
}
