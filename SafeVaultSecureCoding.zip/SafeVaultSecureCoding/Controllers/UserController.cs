using Microsoft.AspNetCore.Mvc;
using SafeVault.Data;
using SafeVault.Services;

namespace SafeVault.Controllers
{
    public class UserController : Controller
    {
        private readonly UserRepository userRepository;

        public UserController()
        {
            string connectionString = "server=localhost;database=SafeVault;user=root;password=;";
            userRepository = new UserRepository(connectionString);
        }

        [HttpPost]
        public IActionResult Submit(string username, string email)
        {
            if (!InputValidator.IsValidUsername(username))
            {
                return BadRequest("Invalid username.");
            }

            if (!InputValidator.IsValidEmail(email))
            {
                return BadRequest("Invalid email.");
            }

            userRepository.AddUser(username, email);

            return Ok("User added securely.");
        }
    }
}
