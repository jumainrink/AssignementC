using System;
using System.Net;
using System.Text.RegularExpressions;

namespace SafeVault.Services
{
    public static class InputValidator
    {
        public static string SanitizeInput(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return string.Empty;

            input = input.Trim();

            // Remove HTML tags such as <script>
            input = Regex.Replace(
                input,
                "<.*?>",
                string.Empty,
                RegexOptions.IgnoreCase
            );

            // Encode remaining HTML special characters
            input = WebUtility.HtmlEncode(input);

            return input;
        }

        public static bool IsValidUsername(string username)
        {
            if (string.IsNullOrWhiteSpace(username))
                return false;

            // Allows letters, numbers, underscore, dash, and dot
            return Regex.IsMatch(username, @"^[a-zA-Z0-9_.-]{3,50}$");
        }

        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            return Regex.IsMatch(
                email,
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$"
            );
        }
    }
}
